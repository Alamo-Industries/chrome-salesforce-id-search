function save_options() {
  const urlInputs = document.querySelectorAll('.url-entry');
  const urls = {};
  
  // Validate and collect all URLs
  for (const entry of urlInputs) {
    const key = entry.querySelector('.urlKey').value.trim().toLowerCase();
    let url = entry.querySelector('.orgUrl').value.trim();
    
    // Validate key format
    if (!/^[a-z]+$/.test(key)) {
      showStatus('URL keys must contain only lowercase letters (a-z)', 'error');
      return;
    }
    
    // Add https:// if no protocol is specified
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    
    urls[key] = url;
  }

  chrome.storage.sync.set({ urls }, function() {
    showStatus('Settings saved!', 'success');
  });
}

function showStatus(message, type) {
  var status = document.getElementById('status');
  status.textContent = message;
  status.className = `status ${type}`;
  status.style.display = 'block';
  setTimeout(function() {
    status.style.display = 'none';
  }, 3000);
}

function restore_options() {
  chrome.storage.sync.get({ urls: {} }, function(items) {
    const container = document.getElementById('urls-container');
    container.innerHTML = ''; // Clear existing entries
    
    // If no URLs saved yet, add three empty entries
    const urls = Object.keys(items.urls).length === 0 ? 
      { '': '', '': '', '': '' } : items.urls;
    
    for (const [key, url] of Object.entries(urls)) {
      addUrlEntry(container, key, url);
    }
  });
}

function addUrlEntry(container, key = '', url = '') {
  const entry = document.createElement('div');
  entry.className = 'url-entry';
  entry.innerHTML = `
    <input type="text" class="urlKey" placeholder="Key (e.g., prod)" value="${key}">
    <input type="url" class="orgUrl" placeholder="https://example.com" value="${url}">
  `;
  container.appendChild(entry);
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options); 